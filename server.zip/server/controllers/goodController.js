const dbConfig = require('../config/db');

// 查询所有电影列表数据(分页)
getAllGoods_admin = (req, res) => {
  const { pagenum, pagesize } = req.body;
  const total = pagenum * pagesize;
  const sql = 'select * from goods limit ' + total + ',' + pagesize;
  const sqlArr = [];
  const callBack = (err, data) => {
    if (err) {
      res.send({
        sql,
        meta: {
          status: 404,
          msg: '数据查询失败',
        },
      });
    } else {
      if (data.length <= 0) {
        res.send({
          meta: { status: 402 },
        });
      }
      res.send({
        data,
        meta: {
          status: 200,
          msg: '数据查询成功',
        },
      });
    }
  };
  dbConfig.sqlConnect(sql, sqlArr, callBack);
};
// 获取所有电影列表数据
getAllGoods = (req, res) => {
  const sql = 'select * from goods';
  const sqlArr = [];
  const callBack = (err, data) => {
    if (err) {
      res.send({
        sql,
        meta: {
          status: 404,
          msg: '数据查询失败',
        },
      });
    } else {
      if (data.length <= 0) {
        res.send({
          meta: { status: 402 },
        });
      }
      res.send({
        data,
        meta: {
          status: 200,
          msg: '数据查询成功',
        },
      });
    }
  };
  dbConfig.sqlConnect(sql, sqlArr, callBack);
};
// 获取前4条做轮播图数据
getSwiperGoods = (req, res) => {
  const sql = 'select * from goods limit 0,4';
  const sqlArr = [];
  const callBack = (err, data) => {
    if (err) {
      res.send({
        sql,
        meta: {
          status: 404,
          msg: '数据查询失败',
        },
      });
    } else {
      if (data.length <= 0) {
        res.send({
          meta: { status: 402 },
        });
      }
      res.send({
        data,
        meta: {
          status: 200,
          msg: '数据查询成功',
        },
      });
    }
  };
  dbConfig.sqlConnect(sql, sqlArr, callBack);
};
// 获取4-10天数据作为本周热门
getHotGoods = (req, res) => {
  const sql = 'select * from goods limit 4,6';
  const sqlArr = [];
  const callBack = (err, data) => {
    if (err) {
      res.send({
        sql,
        meta: {
          status: 404,
          msg: '数据查询失败',
        },
      });
    } else {
      if (data.length <= 0) {
        res.send({
          meta: { status: 402 },
        });
      }
      res.send({
        data,
        meta: {
          status: 200,
          msg: '数据查询成功',
        },
      });
    }
  };
  dbConfig.sqlConnect(sql, sqlArr, callBack);
};
module.exports = {
  getAllGoods_admin,
  getAllGoods,
  getSwiperGoods,
  getHotGoods,
};
